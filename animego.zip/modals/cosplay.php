<div class="portfolio-modal modal fade " id="cosplay_modal" role="dialog" aria-hidden="true" data-dismiss="modal"> 
    <div class="modal-dialog" class="modal-lg" role="document">
        <div class="modal-content" style="height:380px;">
            <h3 style="margin-top:-12%;margin-right:20%;">Competição de Cosplays</h3>
            <div class="close-modal" data-dismiss="modal" aria-hidden="true">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <!--Conteudo aqui-->
            <div class="modal-body">
                
            </div>
        </div>
    </div>
</div>